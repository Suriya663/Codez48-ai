
import path from 'path';
import { fileURLToPath } from 'url';



const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json());
app.use(express.static(path.join(__dirname)));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

import express from 'express';
import dotenv from 'dotenv';
import fetch from 'node-fetch';

dotenv.config();
const REPLICATE_TOKEN = process.env.REPLICATE_TOKEN;
const app = express();
const PORT = process.env.PORT || 3001;

app.use(express.json());

app.post("/generate-video", async (req, res) => {
  try {
    const prompt = req.body.prompt;
    if (!prompt) {
      console.warn("Missing prompt in request body");
      return res.status(400).json({ error: "Prompt is required" });
    }

    const response = await fetch("https://api.replicate.com/v1/models/wan-video/wan-2.2-5b-fast/predictions", {
      method: "POST",
      headers: {
        Authorization: `Token ${REPLICATE_TOKEN}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        input: { prompt }
      })
    });

    const result = await response.json();
    console.log("Replicate response:", result);

    if (result.error) {
      return res.status(500).json({ error: result.error });
    }

    res.json(result);
  } catch (err) {
    console.error("Server error:", err);
    res.status(500).json({ error: "Internal server error", details: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});