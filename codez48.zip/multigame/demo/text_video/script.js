window.onload = () => {
  const promptInput = document.getElementById("prompt");
  const generateBtn = document.getElementById("generateBtn");
  const videoPlayer = document.getElementById("videoPlayer");
  const statusText = document.getElementById("status");

  generateBtn.addEventListener("click", async () => {
    const prompt = promptInput.value.trim();
    if (!prompt) {
      alert("Please enter a prompt");
      return; // ✅ This return is inside the async function
    }

    statusText.textContent = "Generating video...";

    try {
      const response = await fetch("/generate-video", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ prompt })
      });

if (!response.ok) {
  const errorText = await response.text();
  console.error("Server responded with error:", errorText);
  statusText.textContent = "Server error: " + response.status;
  return;
}

      const result = await response.json();

      if (result?.output?.video) {
        videoPlayer.src = result.output.video;
        statusText.textContent = "Video generated successfully!";
      } else {
        statusText.textContent = "No video returned.";
      }
    } catch (err) {
      console.error(err);
      statusText.textContent = "Failed to generate video.";
    }
  });
};