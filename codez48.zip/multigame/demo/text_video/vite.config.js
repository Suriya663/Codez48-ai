// vite.config.js
export default {
  server: {
    open: true,
    proxy: {
      '/generate-video': 'http://localhost:3001'
    }
  }
};