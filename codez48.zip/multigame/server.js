require('dotenv').config(); // Loads environment variables from .env file
const express = require('express');
const cors = require('cors'); // Import cors middleware
const { GoogleGenerativeAI } = require('@google/generative-ai');

const app = express();
const port = 3000;

// Enable CORS for all origins (for development, restrict in production)
app.use(cors());
app.use(express.json()); // Middleware to parse JSON request bodies

// Access your API key as an environment variable
// IMPORTANT: Never hardcode your API key here in production!
const API_KEY = process.env.GEMINI_API_KEY;

if (!API_KEY) {
    console.error("Error: GEMINI_API_KEY environment variable not set.");
    console.error("Please create a .env file in the same directory as server.js with content like: GEMINI_API_KEY='YOUR_API_KEY_HERE'");
    process.exit(1); // Exit if API key is missing
}

const genAI = new GoogleGenerativeAI(API_KEY);

app.post('/chat', async (req, res) => {
    const userMessage = req.body.message;

    if (!userMessage) {
        return res.status(400).json({ error: 'Message is required' });
    }

    try {
        const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" }); // Use 1.5 Flash for speed and cost
        // If you want to maintain conversation history, you'll need to manage it here
        // For simplicity, this example treats each request as a new conversation
        const result = await model.generateContent(userMessage);
        const response = await result.response;
        const text = response.text();

        res.json({ response: text });

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        res.status(500).json({ error: 'Failed to get response from AI' });
    }
});

app.listen(port, () => {
    console.log(`Backend server listening at http://localhost:${port}`);
    console.log(`Remember to set your GEMINI_API_KEY in a .env file!`);
});