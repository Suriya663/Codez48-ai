      

       // Get references to the HTML elements
        const textInput = document.getElementById('input_box');

        // Main function to handle the PDF generation
        function generatePdf() {
            // Get the text from the textarea
            const text = textInput.value;
          
          
            // Create a new jsPDF instance
            const doc = new window.jspdf.jsPDF();

            // Set basic font properties
            doc.setFont('helvetica');
            doc.setFontSize(12);

            // Split the text into an array of lines to handle word wrapping and new pages
            const textLines = doc.splitTextToSize(text, 180);

            // Add text to the document
            let y = 20; // Starting Y position from the top
            const lineHeight = 10; // Space between lines

            // Loop through each line and add it to the PDF
            for (let i = 0; i < textLines.length; i++) {
                // Check if the current line will go beyond the page height
                if (y > 280) { // A safe margin before the bottom of the page
                    doc.addPage();
                    y = 20; // Reset Y position for the new page
                }
                doc.text(textLines[i], 15, y);
                y += lineHeight;
            }

            // Save the PDF file with a name
            doc.save('my-document.pdf');
            
        }

        // Add a click event listener to the button
  textInput.addEventListener('keydown', function(event) {
   
    if (event.key === 'Enter') {
        event.preventDefault(); // Prevent new line if needed
      if(textInput.value==`text=` || textInput.value==`TEXT=`){
        alert("pdf");
        generatePdf();

    }
    }
});

