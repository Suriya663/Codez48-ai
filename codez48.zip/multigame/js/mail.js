const nodemailer = require('nodemailer');

async function sendMail() {
    // 1. Create a Transporter using Gmail's SMTP
    let transporter = nodemailer.createTransport({
        host: 'smtp.gmail.com',
        port: 465,
        secure: true, // Use 'true' if port is 465 (SSL), 'false' for 587 (TLS)
        auth: {
            user: 'rajnaga75556@gmail.com', // Your Gmail address
            pass: 'NAGARAJ@1721' // The App Password you generated
        }
    });

    // 2. Define Email Options
    let mailOptions = {
        from: '"Rajnaga" <rajnaga75556@gmail.com>', // Sender address
        to: 'codez4848@gmail.com', // Recipient address
        subject: 'Hello from Node.js!', // Subject line
        text: 'This is a test email sent from my Node.js application.', // Plain text body
        html: '<b>Hello!</b> This is an <i>HTML</i> test email from my Node.js app.' // HTML body
    };

    // 3. Send the Email
    try {
        let info = await transporter.sendMail(mailOptions);
        console.log('Message sent: %s', info.messageId);
        console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info)); // Useful for testing with Ethereal
    } catch (error) {
        console.error('Error sending email:', error);
    }
}

// Call the function to send the email
sendMail();