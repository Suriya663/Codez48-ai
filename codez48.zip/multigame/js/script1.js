
    var count_mb=0;

function click_btn_one(){

    document.getElementById("install_text").style.display="none";
    document.getElementById("more_mb").style.display="block";
    document.getElementById("more_mb").style.display="flex";

    var counting_list=true;

    setInterval(() => {
        setTimeout(() => {
            if(navigator.onLine){
                if(counting_list){
                    count_mb++;
                    // alert(count_mb)


                // alert(count_mb);
                    if(count_mb<4){
                        document.getElementById("more_mb").innerText="downloading...";
                  

                    }

                else if(count_mb==5){
                    // alert("com");
                    document.getElementById("more_mb").innerText="Preparing...";
                        
                }
                else if(count_mb==6){
                    document.getElementById("more_mb").innerText="Installing...";
                
                }

                   else if(count_mb==7){
                    document.getElementById("more_mb").innerText="Done";
                    count_mb=0;
                          var all_change=document.querySelectorAll("#installing");
                        all_change.forEach(all_change=>{
                            all_change.innerText="Open";
                        })
                        var coin_area1=100;

                    var coin2=document.getElementById("points1").innerText=coin_area1;

                 var get_correct_data=document.getElementById("more_mb").textContent;
                if(get_correct_data=="Done"){
                    document.getElementById("Game_Resource1").style.display="none";                       
                }

                    counting_list=false;
                }
                }
             
            
             }
            else{
                document.getElementById("more_mb").innerText="Waiting For Internet...";
            }
        }, 500);
                
        
        
    }, 1000);
}

function click_codez48ai(){
    var btn_for_all1=document.getElementById("installing").textContent;
    // alert(btn_for_all1)
    if(btn_for_all1=="Open"){
        window.open("ai.html");
    }
    else{
        // alert("fail")
    }
}

     
    

    
          
       
        var login_valid_not=0;
        // alert(login_valid_not);

    setTimeout(() => {
       setInterval(() => {
        login_valid_not=1;
    
        
       var coin2= document.getElementById("points1").textContent;
     localStorage.setItem("store_data",coin2);

     localStorage.setItem("store_data2",login_valid_not);

        //         alert(get_data);
        // alert(coin2);
       }, 10);
        var set_data=localStorage.getItem("store_data");
        document.getElementById("points1").textContent=set_data;
        
        var set_data2=localStorage.getItem("store_data2");
        // alert(set_data2);


        // to all text are open or not
        var check_text=document.getElementById("installing").textContent;
        if(set_data2>0 || check_text=="Open"){
                document.getElementById("Game_Resource1").style.display="none";  
                var btn_for_all2=document.getElementById("installing").innerText="Open";
                console.log(btn_for_all2);
                click_codez48ai();
            var all_change=document.querySelectorAll("#installing");
                                all_change.forEach(all_change=>{
                                    all_change.innerText="Open";
                                })

        }
        else{
         document.getElementById("Game_Resource1").style.display="block";  
         document.getElementById("Game_Resource1").style.display="flex";


        }

    }, 20);

    function click_red_youtube(){
        window.open("https://youtube.com/@codez48?si=Wu3EIWf5hohEIhrx");
    }
console.log("codez48");


// check the battery level
   // Function to update the battery status display
        function updateBatteryStatus(battery) {
            const level = (battery.level * 100).toFixed(0);
            document.getElementById('battery_lev').textContent = `${level}%`;
           var plug= battery.charging ? 'Yes' : 'No';
        //    alert(plug);
           if(plug=="Yes"){
                   setTimeout(() => {
             setInterval(() => {
                document.getElementById("cha_eff1").style.display="none";
            }, 1100);
                document.getElementById("cha_eff1").style.display="block";
                document.getElementById("cha_eff1").style.display="flex";
                document.getElementById("cha_eff1").style.alignItems="center";
                document.getElementById("cha_eff1").style.justifyContent="center";

           }, 1000);
           }
           else{
                document.getElementById("cha_eff1").style.display="none";
        

           }
        }

        // Check if the Battery Status API is supported
        if ('getBattery' in navigator) {
            navigator.getBattery().then(function(battery) {
                // Initial update
                updateBatteryStatus(battery);

                // Add event listeners to update the status whenever it changes
                battery.addEventListener('levelchange', () => updateBatteryStatus(battery));
                battery.addEventListener('chargingchange', () => updateBatteryStatus(battery));

                document.getElementById('api-support-message').textContent = 'Battery Status API is supported.';
            }).catch(function(error) {
                console.error('Error accessing Battery Status API:', error);
                document.getElementById('battery-level').textContent = 'Error';
                document.getElementById('charging-status').textContent = 'Error';
                document.getElementById('api-support-message').textContent = 'Error accessing Battery Status API.';
                document.getElementById('api-support-message').classList.add('unsupported');
            });
        } else {
            // Display a message if the API is not supported
            document.getElementById('battery-level').textContent = 'Not supported';
            document.getElementById('charging-status').textContent = 'Not supported';
            document.getElementById('api-support-message').textContent = 'Battery Status API is not supported in this browser.';
            document.getElementById('api-support-message').classList.add('unsupported');
            console.log('Battery Status API is not supported in this browser.');
        }
