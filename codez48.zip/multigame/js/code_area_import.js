const http = require('http');
const fs = require('fs');
const path = require('path');

function getContentType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  switch (ext) {
    case '.html': return 'text/html';
    case '.js': return 'application/javascript';
    case '.css': return 'text/css';
    case '.png': return 'image/png';
    case '.jpg':
    case '.jpeg': return 'image/jpeg';
    case '.gif': return 'image/gif';
    case '.svg': return 'image/svg+xml';
    default: return 'application/octet-stream';
  }
}

function datas(req, res) {
  let filePath = '';
  if (req.url === '/' || req.url === '/code_editor.html') {
    filePath = path.join(__dirname, '../code_editor.html');
  } else {
    // Serve static files (js, css, images, etc.)
    filePath = path.join(__dirname, '..', req.url);
  }

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Page not found');
    } else {
      res.writeHead(200, { 'Content-Type': getContentType(filePath) });
      res.end(data);
    }
  });
}


const server = http.createServer(datas);
server.listen(3000, () => {
  console.log('Server running at http://localhost:3000');

  // Automatically open the browser window (cross-platform)
  const openCmd = process.platform === 'win32'
    ? 'start'
    : process.platform === 'darwin'
      ? 'open'
      : 'xdg-open';
  require('child_process').exec(`${openCmd} http://localhost:3000`);
});